﻿namespace APIGestionVentas.Models
{
    public class Rol
    {
        public int IdRol { get; set; }
        public string Descripcion { get; set; }
        public DateTime FechaRegistro { get; set; }
        public virtual ICollection<Usuario> Usuarios { get; set; }
    }
}
