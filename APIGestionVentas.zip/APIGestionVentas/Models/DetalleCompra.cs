﻿namespace APIGestionVentas.Models
{
    public class DetalleCompra
    {
        public int IdDetalleCompra { get; set; }
        public int IdCompra { get; set; } // clave foránea
        public Compra ObjetoCompra { get; set; } // Relación con la entidad Compra
        public int IdProducto { get; set; } // clave foránea
        public Producto ObjetoProducto { get; set; } // Relación con la entidad Producto
        public decimal PrecioCompra { get; set; }
        public decimal PrecioVenta { get; set; }
        public int Cantidad { get; set; }
        public decimal MontoTotal { get; set; }
        public DateTime FechaRegistro { get; set; }
    }
}
