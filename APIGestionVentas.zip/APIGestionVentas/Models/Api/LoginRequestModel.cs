#nullable enable
namespace APIGestionVentas.Models.Api;

public class LoginRequestModel
{
    public string? UserName { get; set; }
    public string? Password { get; set; }
}