﻿namespace APIGestionVentas.Models
{
    public class Compra
    {
        public int IdCompra { get; set; }

        public int IdUsuario { get; set; }  // Clave foránea a Usuario
        public Usuario ObjetoUsuario { get; set; }

        public int IdProveedor { get; set; }  // Clave foránea a Proveedor
        public Proveedor ObjetoProveedor { get; set; }

        // Otras propiedades
        public string TipoDocumento { get; set; }
        public string NumeroDocumento { get; set; }
        public decimal MontoTotal { get; set; }
        public DateTime FechaRegistro { get; set; }

        public List<DetalleCompra> ObjetoListaDetalleCompra { get; set; }
    }

    /*
    public class Compra
    {
        public int IdCompra { get; set; }
        public Usuario ObjetoUsuario { get; set; }
        public Proveedor ObjetoProveedor { get; set; }
        public string TipoDocumento { get; set; }
        public string NumeroDocumento { get; set; }
        public decimal MontoTotal { get; set; }
        public List<DetalleCompra> ObjetoListaDetalleCompra { get; set; }
        public string FechaRegistro { get; set; }
    }
    */
}
