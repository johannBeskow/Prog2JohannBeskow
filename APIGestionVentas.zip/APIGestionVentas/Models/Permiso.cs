﻿namespace APIGestionVentas.Models
{
    public class Permiso
    {
        public int IdPermiso { get; set; }
        public int IdRol { get; set; }  // Clave foránea
        
        public string NombreMenu { get; set; }
        public DateTime FechaRegistro { get; set; }

    }
}
