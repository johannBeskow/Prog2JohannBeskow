﻿// Importamos los modelos necesarios y la biblioteca de Entity Framework Core
using APIGestionVentas.Models;
using Microsoft.EntityFrameworkCore;


namespace APIGestionVentas.DBContext
{
    // Clase que representa el contexto de la base de datos
    public class GestionVentasDbContext : DbContext
    {
        // Constructor que recibe las opciones de configuración para el contexto
        public GestionVentasDbContext(DbContextOptions<GestionVentasDbContext> options) : base(options)
        {
        }

        // Definimos las tablas de la base de datos como propiedades de tipo DbSet
        public DbSet<Cliente> CLIENTE { get; set; } // Tabla de Clientes
        public DbSet<Compra> COMPRA { get; set; } // Tabla de Compra
        public DbSet<Venta> VENTA { get; set; } // Tabla de Compra
        public DbSet<DetalleCompra> DETALLE_COMPRA { get; set; }
        public DbSet<DetalleVenta> DETALLE_VENTA { get; set; }
        public DbSet<Proveedor> PROVEEDOR { get; set; } // Tabla de Proveedores
        public DbSet<Usuario> USUARIO { get; set; } // Tabla de Usuario
        public DbSet<Permiso> PERMISO { get; set; } // Tabla de Permisos
        public DbSet<Rol> ROL { get; set; } // Tabla de Roles
        public DbSet<Categoria> CATEGORIA { get; set; } // Tabla de Categorías
        public DbSet<Producto> PRODUCTO { get; set; } // Tabla de Productos

        // Método que se llama al configurar el modelo de la base de datos
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DetalleCompra>()
                .ToTable("DETALLE_COMPRA");

            // Configuración de la entidad Cliente
            modelBuilder.Entity<Cliente>()
                .HasKey(c => c.IdCliente); // Define la clave primaria para la tabla Cliente

            // Configuración de la entidad Permiso
            modelBuilder.Entity<Permiso>()
                .HasKey(p => p.IdPermiso); // Define la clave primaria para la tabla Permiso

            // Configuración de la entidad Rol
            modelBuilder.Entity<Rol>()
                .HasKey(r => r.IdRol); // Define la clave primaria para la tabla Rol

            // Configuración de la entidad Usuario
            modelBuilder.Entity<Usuario>()
                .HasKey(u => u.IdUsuario); // Define la clave primaria para la tabla Usuario

            // Configuración de la relación entre Usuario y Rol
            modelBuilder.Entity<Usuario>()
                .HasOne(u => u.Rol) // Each user has one role
                .WithMany(r => r.Usuarios) // Each role can have many users
                .HasForeignKey(u => u.IdRol) // The foreign key in Usuario is IdRol
        .OnDelete(DeleteBehavior.Restrict);
            // Configuración de la entidad Proveedor
            modelBuilder.Entity<Proveedor>()
                .HasKey(p => p.IdProveedor); // Define la clave primaria para la tabla Proveedor

            // Configuración de la entidad Categoria
            modelBuilder.Entity<Categoria>()
                .HasKey(c => c.IdCategoria); // Define la clave primaria para la tabla Categoria

            // Configuración de la entidad Compra
            modelBuilder.Entity<Compra>()
                .HasKey(c => c.IdCompra); // Define la clave primaria para la tabla Compra

            // Configuración de la entidad DetalleCompra
            modelBuilder.Entity<DetalleCompra>()
                .HasKey(dc => dc.IdDetalleCompra); // Define la clave primaria

            // Configuración de la entidad DetalleVenta
            modelBuilder.Entity<Venta>()
                .HasKey(v => v.IdVenta); // Define la clave primaria

            // Configuración de la entidad DetalleVenta
            modelBuilder.Entity<DetalleVenta>()
                .HasKey(dv => dv.IdDetalleVenta); // Define la clave primaria para DetalleVenta


            // Relación Compra-Usuario
            modelBuilder.Entity<Compra>()
                .HasOne(c => c.ObjetoUsuario) // Una compra tiene un usuario
                .WithMany() // Un usuario puede tener muchas compras (ajústalo si necesitas la colección)
                .HasForeignKey(c => c.IdUsuario)
                .OnDelete(DeleteBehavior.Restrict); // Define el comportamiento de eliminación

            // Relación Compra-Proveedor
            modelBuilder.Entity<Compra>()
                .HasOne(c => c.ObjetoProveedor) // Una compra tiene un proveedor
                .WithMany() // Un proveedor puede tener muchas compras
                .HasForeignKey(c => c.IdProveedor)
                .OnDelete(DeleteBehavior.Restrict);

            // Configuración de la entidad Producto
            modelBuilder.Entity<Producto>()
                .HasKey(p => p.IdProducto); // Define la clave primaria para la tabla Producto

            // Mapeo de la propiedad NombreProducto a la columna Nombre en la tabla PRODUCTO
            modelBuilder.Entity<Producto>()
                .Property(p => p.NombreProducto)
                .HasColumnName("Nombre");

            // Relación Producto-Categoria usando la clave foránea IdCategoria
            modelBuilder.Entity<Producto>()
                .HasOne(p => p.ObjetoCategoria) // Un producto tiene una categoría
                .WithMany() // Una categoría puede tener muchos productos
                .HasForeignKey(p => p.IdCategoria) // Usa la propiedad de clave foránea directamente
                .OnDelete(DeleteBehavior.Restrict); // Define el comportamiento de eliminación


            modelBuilder.Entity<Venta>()
                .HasOne(v => v.ObjetoUsuario)
                .WithMany() // O puedes definir la colección en Usuario si lo necesitas
                .HasForeignKey(v => v.IdUsuario)
                .OnDelete(DeleteBehavior.Restrict);


            modelBuilder.Entity<Venta>()
                .HasMany(v => v.ObjetoListaDetalleVenta)
                .WithOne(dv => dv.ObjetoVenta)
                .HasForeignKey(dv => dv.IdVenta)
                .OnDelete(DeleteBehavior.Restrict);





        }
    }
}
