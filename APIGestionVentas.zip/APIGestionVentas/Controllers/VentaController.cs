﻿using APIGestionVentas.DBContext; // Importa el contexto de la base de datos para interactuar con la misma
using APIGestionVentas.Models; // Importa las entidades de modelo
using APIGestionVentas.Models.DTO_s; // Importa los DTOs (Data Transfer Objects) utilizados para la comunicación
using Microsoft.AspNetCore.Mvc; // Importa las herramientas necesarias para crear controladores de API
using Microsoft.EntityFrameworkCore; // Importa las extensiones para trabajar con Entity Framework Core

namespace APIGestionVentas.Controllers // Define el espacio de nombres para el controlador
{
    [Route("api/[controller]")] // Define la ruta base para las solicitudes a este controlador
    [ApiController] // Indica que esta clase es un controlador API y aplica ciertos comportamientos automáticamente
    public class VentaController : ControllerBase // Clase que hereda de ControllerBase, lo que permite manejar solicitudes HTTP
    {
        private readonly GestionVentasDbContext _context; // Variable para el contexto de la base de datos

        // Constructor que recibe el contexto de la base de datos
        public VentaController(GestionVentasDbContext context)
        {
            _context = context; // Inicializa el contexto
        }

        // GET: api/Venta
        [HttpGet("Get-Ventas")] // Define un endpoint GET para obtener todas las ventas
        public async Task<ActionResult<IEnumerable<Venta>>> GetVentas()
        {
            // Obtiene todas las ventas de la base de datos de forma asíncrona
            var ventas = await _context.VENTA.ToListAsync();

            // Proyecta el resultado a un formato más simple (anónimo) para la respuesta
            var resultado = ventas.Select(venta => new
            {
                venta.IdVenta,
                venta.IdUsuario,
                venta.TipoDocumento,
                venta.NumeroDocumento,
                venta.DocumentoCliente,
                venta.NombreCliente,
                venta.MontoPago,
                venta.MontoTotal,
                venta.FechaRegistro
            });

            return Ok(resultado); // Devuelve un 200 OK con el resultado
        }

        // GET: api/Venta/{id}
        [HttpGet("Get-Venta-Id{id}")] // Define un endpoint GET para obtener una venta específica por ID
        public async Task<ActionResult> GetVenta(int id)
        {
            // Busca la venta con el ID proporcionado
            var venta = await _context.VENTA.FirstOrDefaultAsync(v => v.IdVenta == id);

            if (venta == null) // Si no se encuentra la venta
            {
                return NotFound(new { mensaje = "Venta no encontrada" }); // Devuelve un 404 Not Found
            }

            // Proyecta la venta encontrada a un formato más simple (anónimo)
            var resultado = new
            {
                venta.IdVenta,
                venta.IdUsuario,
                venta.TipoDocumento,
                venta.NumeroDocumento,
                venta.DocumentoCliente,
                venta.NombreCliente,
                venta.MontoPago,
                venta.MontoTotal,
                venta.FechaRegistro
            };

            return Ok(resultado); // Devuelve un 200 OK con el resultado
        }

        // POST: api/Venta
        [HttpPost("Crear-Venta")] // Define un endpoint POST para crear una nueva venta
        public async Task<ActionResult> CrearVenta([FromBody] VentaDto ventaDto)
        {
            // Crea una nueva instancia de Venta y mapea los valores desde el DTO
            var nuevaVenta = new Venta
            {
                IdUsuario = ventaDto.IdUsuario,
                TipoDocumento = ventaDto.TipoDocumento,
                NumeroDocumento = ventaDto.NumeroDocumento,
                DocumentoCliente = ventaDto.DocumentoCliente,
                NombreCliente = ventaDto.NombreCliente,
                MontoPago = ventaDto.MontoPago,
                MontoCambio = ventaDto.MontoCambio, // Esta propiedad se asigna desde el DTO
                MontoTotal = ventaDto.MontoTotal,
                FechaRegistro = ventaDto.FechaRegistro,
                
            };

            _context.VENTA.Add(nuevaVenta); // Agrega la nueva venta al contexto
            await _context.SaveChangesAsync(); // Guarda los cambios en la base de datos

            // Asigna el ID generado a `ventaDto` si es necesario
            ventaDto.IdVenta = nuevaVenta.IdVenta;

            // Devuelve un 201 Created con la ubicación de la nueva venta creada
            return CreatedAtAction(nameof(GetVenta), new { id = ventaDto.IdVenta }, ventaDto);
        }

        // PUT: api/Venta/{id}
        [HttpPut("Modificar-Venta{id}")] // Define un endpoint PUT para modificar una venta existente
        public async Task<IActionResult> ModificarVenta(int id, [FromBody] VentaDto ventaDto)
        {
            // Verifica si el ID de la venta en la URL coincide con el ID del DTO
            if (id != ventaDto.IdVenta)
            {
                return BadRequest("El ID de la venta no coincide."); // Devuelve un 400 Bad Request si no coinciden
            }

            // Busca la venta correspondiente en la base de datos
            var venta = await _context.VENTA.FindAsync(id);
            if (venta == null) // Si no se encuentra la venta
            {
                return NotFound("Venta no encontrada."); // Devuelve un 404 Not Found
            }

            // Actualiza las propiedades de la venta con los valores del DTO
            venta.IdUsuario = ventaDto.IdUsuario;
            venta.TipoDocumento = ventaDto.TipoDocumento;
            venta.NumeroDocumento = ventaDto.NumeroDocumento;
            venta.DocumentoCliente = ventaDto.DocumentoCliente;
            venta.NombreCliente = ventaDto.NombreCliente;
            venta.MontoPago = ventaDto.MontoPago;
            venta.MontoCambio = ventaDto.MontoCambio; // Asegúrate de que esta propiedad esté en el modelo de Venta
            venta.MontoTotal = ventaDto.MontoTotal;
            venta.FechaRegistro = ventaDto.FechaRegistro;

            try
            {
                await _context.SaveChangesAsync(); // Guarda los cambios en la base de datos
            }
            catch (DbUpdateConcurrencyException) // Maneja excepciones de concurrencia
            {
                if (!VentaExists(id)) // Verifica si la venta sigue existiendo
                {
                    return NotFound("Venta no encontrada."); // Devuelve un 404 Not Found
                }
                else
                {
                    throw; // Lanza la excepción si ocurre otro error
                }
            }

            return NoContent(); // Devuelve un 204 No Content si la actualización fue exitosa
        }

        // Método privado para verificar si una venta existe en la base de datos
        private bool VentaExists(int id)
        {
            return _context.VENTA.Any(e => e.IdVenta == id); // Retorna verdadero si existe una venta con el ID proporcionado
        }

        // DELETE: api/Venta/{id}
        [HttpDelete("Eliminar-Venta{id}")] // Define un endpoint DELETE para eliminar una venta por ID
        public async Task<IActionResult> EliminarVenta(int id)
        {
            // Busca la venta correspondiente en la base de datos
            var venta = await _context.VENTA.FindAsync(id);
            if (venta == null) // Si no se encuentra la venta
            {
                return NotFound("Venta no encontrada."); // Devuelve un 404 Not Found
            }

            _context.VENTA.Remove(venta); // Elimina la venta del contexto
            await _context.SaveChangesAsync(); // Guarda los cambios en la base de datos

            return NoContent(); // Devuelve un 204 No Content si la eliminación fue exitosa
        }
    }
}
