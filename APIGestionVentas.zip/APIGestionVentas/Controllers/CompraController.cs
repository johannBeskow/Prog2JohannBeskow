﻿using APIGestionVentas.DBContext;
using APIGestionVentas.Models;
using APIGestionVentas.Models.DTO_s;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APIGestionVentas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompraController : ControllerBase
    {
        private readonly GestionVentasDbContext _context;

        // Constructor: Inicializa el contexto de base de datos inyectado.
        public CompraController(GestionVentasDbContext context)
        {
            _context = context;
        }

        // Método GET para obtener todas las compras
        [HttpGet("Get-Compras")]
        public async Task<ActionResult<IEnumerable<object>>> GetCompras()
        {
            // Obtenemos la lista de compras de manera asíncrona, sin incluir los objetos de navegación.
            var compras = await _context.COMPRA.ToListAsync();

            // Creamos una lista de objetos anónimos sin los campos de navegación.
            var resultado = compras.Select(compra => new
            {
                compra.IdCompra,
                compra.IdUsuario,
                compra.IdProveedor,
                compra.TipoDocumento,
                compra.NumeroDocumento,
                compra.MontoTotal,
                compra.FechaRegistro
            });

            // Retornamos una respuesta exitosa con la lista de compras.
            return Ok(resultado);
        }

        // Método GET para obtener una compra por su ID
        [HttpGet("Get-Compra-Id/{id}")]
        public async Task<ActionResult<object>> GetCompraById(int id)
        {
            // Busca la compra por ID, sin incluir los objetos de navegación.
            var compra = await _context.COMPRA
                .Where(c => c.IdCompra == id)
                .Select(c => new
                {
                    c.IdCompra,
                    c.IdUsuario,
                    c.IdProveedor,
                    c.TipoDocumento,
                    c.NumeroDocumento,
                    c.MontoTotal,
                    c.FechaRegistro
                })
                .FirstOrDefaultAsync();

            // Verifica si la compra existe
            if (compra == null)
            {
                return NotFound(); // Retorna 404 si no se encuentra la compra
            }

            return Ok(compra); // Retorna la compra sin los objetos de navegación
        }

        // Método GET para obtener el usuario asociado a una compra por ID
        [HttpGet("Get-Usuario-Compra/{id}")]
        public async Task<ActionResult<object>> GetUsuarioByCompra(int id)
        {
            // Busca la compra por ID e incluye la relación del usuario.
            var compra = await _context.COMPRA
                .Include(c => c.ObjetoUsuario)  // Incluir la relación con el usuario.
                .FirstOrDefaultAsync(c => c.IdCompra == id);

            // Verifica si la compra existe.
            if (compra == null)
            {
                return NotFound();
            }

            // Obtén el usuario asociado a la compra.
            var usuario = compra.ObjetoUsuario;

            // Verifica si el usuario existe.
            if (usuario == null)
            {
                return NotFound("Usuario no encontrado");
            }

            // Selecciona solo las propiedades relevantes del usuario.
            var ObtenerUsuario = new
            {
                usuario.IdUsuario,
                usuario.IdRol,
                usuario.Documento,
                usuario.NombreCompleto,
                usuario.Correo,
                usuario.Estado,
                usuario.FechaRegistro
            };

            // Retorna el usuario en formato de objeto anónimo.
            return Ok(ObtenerUsuario);
        }

        // Método GET para obtener el proveedor asociado a una compra por ID
        [HttpGet("Proveedor/{id}")]
        public async Task<ActionResult<Proveedor>> GetProveedorByCompra(int id)
        {
            // Busca la compra por ID e incluye la relación con el proveedor.
            var compra = await _context.COMPRA
                .Include(c => c.ObjetoProveedor)  // Incluir la relación con el proveedor.
                .FirstOrDefaultAsync(c => c.IdCompra == id);

            // Verifica si la compra existe.
            if (compra == null)
            {
                return NotFound("Compra no encontrada");
            }

            // Obtén el proveedor asociado a la compra.
            var proveedor = compra.ObjetoProveedor;

            // Verifica si el proveedor existe.
            if (proveedor == null)
            {
                return NotFound("Proveedor no encontrado");
            }

            // Retorna el proveedor sin los objetos de navegación.
            return Ok(new
            {
                proveedor.IdProveedor,
                proveedor.RazonSocial,  // Propiedad a mostrar
                proveedor.Documento,
                proveedor.Estado,
                proveedor.FechaRegistro
            });
        }

        // Método GET para obtener el monto total de una compra por ID
        [HttpGet("MontoTotal/{id}")]
        public async Task<ActionResult<decimal>> GetMontoTotalByCompra(int id)
        {
            // Busca la compra por ID.
            var compra = await _context.COMPRA
                .Select(c => new { c.IdCompra, c.MontoTotal }) // Selecciona solo el IdCompra y MontoTotal
                .FirstOrDefaultAsync(c => c.IdCompra == id);

            // Verifica si la compra existe.
            if (compra == null)
            {
                return NotFound("Compra no encontrada");
            }

            // Retorna el monto total de la compra.
            return Ok(compra.MontoTotal);
        }

        // Método POST para crear una nueva compra
        [HttpPost("Crear-Compra")]
        public async Task<ActionResult<CompraDto>> CrearCompra(CompraDto compraDto)
        {
            // Validar que el usuario exista
            var usuarioExistente = await _context.USUARIO.FindAsync(compraDto.IdUsuario);
            if (usuarioExistente == null)
            {
                return BadRequest("El usuario no existe.");
            }

            // Validar que el proveedor exista
            var proveedorExistente = await _context.PROVEEDOR.FindAsync(compraDto.IdProveedor);
            if (proveedorExistente == null)
            {
                return BadRequest("El proveedor no existe.");
            }

            // Crear el objeto Compra basado en el DTO
            var compra = new Compra
            {
                IdUsuario = compraDto.IdUsuario,
                ObjetoUsuario = usuarioExistente,
                IdProveedor = compraDto.IdProveedor,
                ObjetoProveedor = proveedorExistente,
                TipoDocumento = compraDto.TipoDocumento,
                NumeroDocumento = compraDto.NumeroDocumento,
                MontoTotal = compraDto.MontoTotal,
                FechaRegistro = compraDto.FechaRegistro,
                ObjetoListaDetalleCompra = new List<DetalleCompra>() // Iniciar una lista vacía de detalles de compra
            };

            _context.COMPRA.Add(compra);
            await _context.SaveChangesAsync();

            // Retornar el DTO con el IdCompra generado
            compraDto.IdCompra = compra.IdCompra;

            return CreatedAtAction(nameof(GetCompraById), new { id = compra.IdCompra }, compraDto);
        }

        // Método PUT para modificar una compra existente
        [HttpPut("Modificar-Compra/{id}")]
        public async Task<IActionResult> ModificarCompra(int id, CompraDto compraDto)
        {
            // Verificar si el ID de la compra coincide con el ID del DTO
            if (id != compraDto.IdCompra)
            {
                return BadRequest("El ID de la compra no coincide con el proporcionado en el cuerpo de la solicitud.");
            }

            // Validar que el usuario exista
            var usuarioExistente = await _context.USUARIO.FindAsync(compraDto.IdUsuario);
            if (usuarioExistente == null)
            {
                return BadRequest("El usuario no existe.");
            }

            // Validar que el proveedor exista
            var proveedorExistente = await _context.PROVEEDOR.FindAsync(compraDto.IdProveedor);
            if (proveedorExistente == null)
            {
                return BadRequest("El proveedor no existe.");
            }

            // Buscar la compra existente
            var compraExistente = await _context.COMPRA.FindAsync(id);
            if (compraExistente == null)
            {
                return NotFound("Compra no encontrada.");
            }

            // Actualizar las propiedades de la compra
            compraExistente.IdUsuario = compraDto.IdUsuario;
            compraExistente.ObjetoUsuario = usuarioExistente;
            compraExistente.IdProveedor = compraDto.IdProveedor;
            compraExistente.ObjetoProveedor = proveedorExistente;
            compraExistente.TipoDocumento = compraDto.TipoDocumento;
            compraExistente.NumeroDocumento = compraDto.NumeroDocumento;
            compraExistente.MontoTotal = compraDto.MontoTotal;
            compraExistente.FechaRegistro = compraDto.FechaRegistro;

            // Marcar el estado de la compra como modificado
            _context.Entry(compraExistente).State = EntityState.Modified;

            try
            {
                // Guardar los cambios en la base de datos
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CompraExists(id))
                {
                    return NotFound("La compra no existe.");
                }
                else
                {
                    throw;
                }
            }

            return NoContent(); // Retorna un 204 No Content al actualizar correctamente
        }

        // Método auxiliar para verificar si una compra existe
        private bool CompraExists(int id)
        {
            return _context.COMPRA.Any(e => e.IdCompra == id);
        }

        // Método DELETE para eliminar una compra existente
        [HttpDelete("Eliminar-Compra/{id}")]
        public async Task<IActionResult> EliminarCompra(int id)
        {
            // Buscar la compra existente por ID
            var compra = await _context.COMPRA.FindAsync(id);
            if (compra == null)
            {
                return NotFound("Compra no encontrada.");
            }

            // Remover la compra del contexto y guardar cambios
            _context.COMPRA.Remove(compra);
            await _context.SaveChangesAsync();

            return NoContent(); // Retorna 204 No Content al eliminar correctamente
        }
    }
}
