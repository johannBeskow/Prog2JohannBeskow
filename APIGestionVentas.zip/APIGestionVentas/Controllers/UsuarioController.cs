﻿// Importamos las bibliotecas necesarias para crear controladores de API, trabajar con Entity Framework y definir modelos.
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using APIGestionVentas.DBContext;
using APIGestionVentas.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace APIGestionVentas.Controllers
{
    // Define la ruta base para acceder a los métodos de este controlador. Por ejemplo, "api/usuarios".
    [Route("api/[controller]")]
    // Indica que esta clase es un controlador de API y permite la comunicación a través de HTTP.
    [ApiController]
    [Authorize(Policy = "AdminOnly")]
    
    public class UsuariosController : ControllerBase
    {
        // Creamos una variable privada para almacenar el contexto de la base de datos.
        private readonly GestionVentasDbContext _context;

        // Constructor que recibe el contexto de la base de datos como parámetro.
        public UsuariosController(GestionVentasDbContext context)
        {
            _context = context; // Asignamos el contexto recibido a la variable privada.
        }

        // Método para obtener todos los usuarios.
        // Ruta: GET api/usuarios/GetUsuarios
        [HttpGet("Get-Usuarios")]
        public async Task<ActionResult<IEnumerable<object>>> GetUsuarios()
        {
            // Obtenemos la lista de usuarios de manera asíncrona.
            var usuarios = await _context.USUARIO.Include(u => u.Rol).ToListAsync();

            // Creamos una lista de objetos anónimos sin el campo NavegacionRol.
            var resultado = usuarios.Select(usuario => new
            {
                usuario.IdUsuario,
                usuario.IdRol,
                usuario.Documento,
                usuario.NombreCompleto,
                usuario.Correo,
                usuario.Clave,
                usuario.Estado,
                usuario.FechaRegistro,
            });

            // Retornamos una respuesta exitosa con la lista de usuarios.
            return Ok(resultado);
        }

        // Método para obtener un usuario específico por su ID.
        // Ruta: GET api/usuarios/GetUsuarioPorId/{id}
        [HttpGet("Get-Usuario-Id/{id}")]
        public async Task<ActionResult<object>> GetUsuario(int id)
        {
            // Buscamos el usuario en la base de datos utilizando su ID.
            var usuario = await _context.USUARIO.FindAsync(id);
            if (usuario == null)
            {
                return NotFound(); // Si no se encuentra, retornamos un 404 Not Found.
            }

            // Retornamos un objeto anónimo omitiendo NavegacionRol.
            var resultado = new
            {
                usuario.IdUsuario,
                usuario.IdRol,
                usuario.Documento,
                usuario.NombreCompleto,
                usuario.Correo,
                usuario.Clave,
                usuario.Estado,
                usuario.FechaRegistro
            };

            // Retornamos la información del usuario.
            return Ok(resultado);
        }

        // Método para obtener el rol de un usuario específico.
        // Ruta: GET api/usuarios/ObtenerRol/{id}/roles
        [HttpGet("Get-Rol/{id}/roles")]
        public async Task<ActionResult<Rol>> GetRolesPorUsuario(int id)
        {
            // Buscamos el usuario por ID, incluyendo su rol.
            var usuario = await _context.USUARIO.Include(u => u.Rol)
                .FirstOrDefaultAsync(u => u.IdUsuario == id);

            if (usuario == null)
            {
                return NotFound($"El usuario con ID {id} no existe."); // Retorna 404 si no se encuentra el usuario.
            }

            // Retornamos el rol del usuario.
            return Ok(usuario.Rol);
        }

        // Método para crear un nuevo usuario.
        // Ruta: POST api/usuarios/CrearUsuario
        [HttpPost("Crear-Usuario")]
        public async Task<ActionResult<Usuario>> CrearUsuario(Usuario usuario)
        {
            // Validamos el modelo para asegurarnos de que los datos son correctos.
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Retornamos 400 Bad Request si hay errores en los datos.
            }

            // Verificamos si el rol existe en la base de datos.
            var rolExistente = await _context.ROL.FindAsync(usuario.IdRol);
            if (rolExistente == null)
            {
                return NotFound($"El rol con ID {usuario.IdRol} no existe."); // Retorna 404 si el rol no se encuentra.
            }

            // Asignamos el rol existente al nuevo usuario.
            usuario.Rol = rolExistente;

            // Agregamos el nuevo usuario al contexto de la base de datos.
            _context.USUARIO.Add(usuario);
            await _context.SaveChangesAsync(); // Guardamos los cambios en la base de datos.

            // Retornamos el nuevo usuario creado con un 201 Created.
            return CreatedAtAction(nameof(GetUsuario), new { id = usuario.IdUsuario }, usuario);
        }

        // Método para actualizar un usuario existente.
        // Ruta: PUT api/usuarios/ActualizarUsuario/{id}
        [HttpPut("Modificar-Usuario/{id}")]
        public async Task<ActionResult<Usuario>> ModificarUsuario(int id, Usuario usuario)
        {
            // Verificamos que el ID en la URL coincida con el del objeto.
            if (id != usuario.IdUsuario)
            {
                return BadRequest($"El ID en la URL ({id}) no coincide con el ID del usuario en el cuerpo de la solicitud ({usuario.IdUsuario}).");
            }

            // Validamos el modelo.
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Retornamos 400 Bad Request si hay errores en los datos.
            }

            // Verificamos si el rol existe en la base de datos.
            var rolExistente = await _context.ROL.FindAsync(usuario.IdRol);
            if (rolExistente == null)
            {
                return NotFound($"El rol con ID {usuario.IdRol} no existe."); // Retorna 404 si el rol no se encuentra.
            }

            // Asignamos el rol existente al usuario.
            usuario.Rol = rolExistente;

            // Marcamos el usuario como modificado en el contexto.
            _context.Entry(usuario).State = EntityState.Modified;

            try
            {
                // Guardamos los cambios en la base de datos.
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                // Manejamos el caso en que el usuario ya no existe en la base de datos.
                if (!UsuarioExists(id))
                {
                    return NotFound($"El usuario con ID {id} no existe.");
                }
                else
                {
                    throw; // Lanzamos la excepción si es otro error.
                }
            }

            // Retornamos el usuario actualizado.
            return Ok(usuario);
        }

        // Método privado para verificar si un usuario existe en la base de datos.
        private bool UsuarioExists(int id)
        {
            return _context.USUARIO.Any(e => e.IdUsuario == id); // Retorna verdadero si existe un usuario con ese ID.
        }

        // Método para eliminar un usuario.
        // Ruta: DELETE api/usuarios/EliminarUsuario/{id}
        [HttpDelete("Eliminar-Usuario/{id}")]

        public async Task<IActionResult> EliminarUsuario(int id)
        {
            var usuario = await _context.USUARIO.FindAsync(id);
            if (usuario == null)
                return NotFound("No se ha encontrado un usuario con este id");

            bool hasRelatedCompras = await _context.COMPRA.AnyAsync(c => c.IdUsuario == id);
            bool hasRelatedVentas = await _context.VENTA.AnyAsync(v => v.IdUsuario == id);
            if (hasRelatedCompras || hasRelatedVentas)
                return BadRequest("Este usuario está asociado a compras o ventas. No se puede eliminar");

            _context.USUARIO.Remove(usuario);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
