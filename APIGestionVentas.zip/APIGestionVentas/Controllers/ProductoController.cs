﻿using APIGestionVentas.DBContext;
using APIGestionVentas.Models;
using APIGestionVentas.Models.DTO_s;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APIGestionVentas.Controllers
{
    // Definimos la ruta base para el controlador y especificamos que es un controlador de API.
    [Route("api/[controller]")]
    [ApiController]
    public class ProductoController : ControllerBase
    {
        // Definimos un campo privado para el contexto de base de datos.
        private readonly GestionVentasDbContext _context;

        // Constructor del controlador que inyecta el contexto de la base de datos.
        public ProductoController(GestionVentasDbContext context)
        {
            _context = context;
        }

        // Método para obtener todos los productos.
        // GET: api/Producto
        [HttpGet("Get-Productos")]
        public async Task<ActionResult<IEnumerable<object>>> GetProductos()
        {
            // Obtenemos la lista de productos y proyectamos solo las propiedades necesarias.
            var productos = await _context.PRODUCTO
                .Select(p => new
                {
                    p.IdProducto,
                    p.Codigo,
                    p.NombreProducto,
                    p.Descripcion,
                    p.IdCategoria, // Incluimos solo el Id de la categoría
                    p.Stock,
                    p.PrecioCompra,
                    p.PrecioVenta,
                    p.Estado,
                    p.FechaRegistro
                })
                .ToListAsync();

            // Retornamos la lista de productos proyectada.
            return Ok(productos);
        }

        // Método para obtener un producto por su ID.
        // GET: api/Producto/5
        [HttpGet("Get-Producto-Id{id}")]
        public async Task<ActionResult<object>> GetProducto(int id)
        {
            // Busca el producto por su ID y proyecta las propiedades necesarias.
            var producto = await _context.PRODUCTO
                .Where(p => p.IdProducto == id)
                .Select(p => new
                {
                    p.IdProducto,
                    p.Codigo,
                    p.NombreProducto,
                    p.Descripcion,
                    p.IdCategoria, // Incluimos solo el Id de la categoría
                    p.Stock,
                    p.PrecioCompra,
                    p.PrecioVenta,
                    p.Estado,
                    p.FechaRegistro
                })
                .FirstOrDefaultAsync();

            // Verifica si el producto existe.
            if (producto == null)
            {
                return NotFound(); // Retorna 404 si no se encuentra el producto
            }

            // Retorna el producto proyectado.
            return Ok(producto);
        }

        // Método para obtener la categoría de un producto dado su ID.
        // GET: api/Producto/{id}/Categoria
        [HttpGet("Get-Categoria{id}")]
        public async Task<ActionResult<Categoria>> GetCategoriaDelProducto(int id)
        {
            var producto = await _context.PRODUCTO
                .Include(p => p.ObjetoCategoria) // Incluir el objeto de navegación de la categoría
                .FirstOrDefaultAsync(p => p.IdProducto == id);

            if (producto == null)
            {
                return NotFound();
            }

            return producto.ObjetoCategoria; // Devolver el objeto de la categoría
        }

        // Método para obtener el precio de compra de un producto.
        // GET: api/Producto/{id}/PrecioCompra
        [HttpGet("Get-PrecioCompra{id}")]
        public async Task<ActionResult<decimal>> GetPrecioCompraDelProducto(int id)
        {
            var producto = await _context.PRODUCTO
                .Where(p => p.IdProducto == id)
                .Select(p => p.PrecioCompra) // Seleccionar solo el precio de compra
                .FirstOrDefaultAsync();

            if (producto == 0) // Asumiendo que un precio de compra de 0 indica que no se encontró el producto
            {
                return NotFound();
            }

            return producto; // Devolver solo el precio de compra
        }

        // Método para obtener el precio de venta de un producto.
        // GET: api/Producto/{id}/PrecioVenta
        [HttpGet("Get-PrecioVenta{id}")]
        public async Task<ActionResult<decimal>> GetPrecioVentaDelProducto(int id)
        {
            var producto = await _context.PRODUCTO
                .Where(p => p.IdProducto == id)
                .Select(p => p.PrecioVenta) // Seleccionar solo el precio de venta
                .FirstOrDefaultAsync();

            if (producto == 0) // Asumiendo que un precio de venta de 0 indica que no se encontró el producto
            {
                return NotFound();
            }

            return producto; // Devolver solo el precio de venta
        }

        // Método para obtener el stock de un producto.
        // GET: api/Producto/{id}/Stock
        [HttpGet("Get-Stock{id}")]
        public async Task<ActionResult<int>> GetStockDelProducto(int id)
        {
            var producto = await _context.PRODUCTO
                .Where(p => p.IdProducto == id)
                .Select(p => p.Stock) // Seleccionar solo el stock
                .FirstOrDefaultAsync();

            if (producto == 0) // Asumiendo que un stock de 0 indica que no se encontró el producto
            {
                return NotFound();
            }

            return producto; // Devolver solo el stock
        }

        // Método para crear un nuevo producto.
        // POST: api/Producto
        [HttpPost("Crear-Producto")]
        public async Task<ActionResult<ProductoDto>> CrearProducto(ProductoDto productoDTO)
        {
            // Busca la categoría existente por el IdCategoria
            var categoriaExistente = await _context.CATEGORIA.FindAsync(productoDTO.IdCategoria);
            if (categoriaExistente == null)
            {
                return BadRequest("La categoría no existe.");
            }

            // Crear el objeto Producto sin incluir el objeto de navegación
            var producto = new Producto
            {
                Codigo = productoDTO.Codigo,
                NombreProducto = productoDTO.NombreProducto,
                Descripcion = productoDTO.Descripcion,
                IdCategoria = productoDTO.IdCategoria,
                Stock = productoDTO.Stock,
                PrecioCompra = productoDTO.PrecioCompra,
                PrecioVenta = productoDTO.PrecioVenta,
                Estado = productoDTO.Estado,
                FechaRegistro = productoDTO.FechaRegistro,
                ObjetoCategoria = categoriaExistente  // Asignar la categoría existente
            };

            _context.PRODUCTO.Add(producto);
            await _context.SaveChangesAsync();

            productoDTO.IdProducto = producto.IdProducto;

            return CreatedAtAction(nameof(GetProducto), new { id = producto.IdProducto }, productoDTO);
        }

        // Método para modificar un producto existente.
        // PUT: api/Producto/5
        [HttpPut("Modificar-Producto{id}")]
        public async Task<IActionResult> ModificarProducto(int id, Producto producto)
        {
            if (id != producto.IdProducto)
            {
                return BadRequest();
            }

            // Verificar si la categoría existe en la base de datos
            var categoriaExistente = await _context.CATEGORIA.FindAsync(producto.IdCategoria);
            if (categoriaExistente == null)
            {
                return BadRequest("La categoría no existe.");
            }

            // Asignar la categoría existente al producto
            producto.ObjetoCategoria = categoriaExistente;

            _context.Entry(producto).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // Método para eliminar un producto por su ID.
        // DELETE: api/Producto/5
        [HttpDelete("Eliminar-Producto{id}")]
        public async Task<IActionResult> EliminarProducto(int id)
        {
            var producto = await _context.PRODUCTO.FindAsync(id);
            if (producto == null)
                return NotFound("No se ha encontrado un producto con este id");

            bool hasRelatedDetalleCompras = await _context.DETALLE_COMPRA.AnyAsync(dc => dc.IdProducto == id);
            bool hasRelatedDetalleVentas = await _context.DETALLE_VENTA.AnyAsync(dv => dv.IdProducto == id);
            if (hasRelatedDetalleCompras || hasRelatedDetalleVentas)
                return BadRequest("Este producto está asociado a compras o ventas. No se puede eliminar");

            _context.PRODUCTO.Remove(producto);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // Método auxiliar para verificar si un producto existe.
        private bool ProductoExists(int id)
        {
            return _context.PRODUCTO.Any(e => e.IdProducto == id);
        }
    }
}
