using APIGestionVentas.DBContext;
using APIGestionVentas.DTOs;
using APIGestionVentas.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APIGestionVentas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DetalleVentaController : ControllerBase
    {
        private readonly GestionVentasDbContext _context;

        public DetalleVentaController(GestionVentasDbContext context)
        {
            _context = context;
        }

        // GET: api/DetalleVenta
        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetDetallesVenta()
        {
            // Obtiene todos los detalles de venta
            var detalles = await _context.DETALLE_VENTA
                .Select(dv => new
                {
                    dv.IdDetalleVenta,
                    dv.IdVenta,
                    dv.IdProducto,
                    dv.PrecioVenta,
                    dv.Cantidad,
                    dv.SubTotal,
                    dv.FechaRegistro
                })
                .ToListAsync();

            return Ok(detalles); // Retorna la lista de detalles
        }

        // GET: api/DetalleVenta/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<object>> GetDetalleVenta(int id)
        {
            // Busca el detalle de venta por ID
            var detalle = await _context.DETALLE_VENTA
                .Where(dv => dv.IdDetalleVenta == id)
                .Select(dv => new
                {
                    dv.IdDetalleVenta,
                    dv.IdVenta,
                    dv.IdProducto,
                    dv.PrecioVenta,
                    dv.Cantidad,
                    dv.SubTotal,
                    dv.FechaRegistro
                })
                .FirstOrDefaultAsync();

            // Verifica si el detalle existe
            if (detalle == null)
            {
                return NotFound(); // Retorna 404 si no se encuentra el detalle
            }

            return Ok(detalle); // Retorna el detalle de venta
        }

        // POST: api/DetalleVenta
        [HttpPost]
        public async Task<ActionResult<DetalleVenta>> PostDetalleVenta(DetalleVenta detalleVenta)
        {
            // Verifica si la entidad es válida
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Añade el nuevo detalle de venta
            _context.DETALLE_VENTA.Add(detalleVenta);
            await _context.SaveChangesAsync();

            // Retorna un 201 (creado) con la ubicación del nuevo recurso
            return CreatedAtAction("GetDetalleVenta", new { id = detalleVenta.IdDetalleVenta }, detalleVenta);
        }

        // DELETE: api/DetalleVenta/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDetalleVenta(int id)
        {
            // Busca el detalle de venta por ID
            var detalleVenta = await _context.DETALLE_VENTA.FindAsync(id);

            // Verifica si el detalle existe
            if (detalleVenta == null)
            {
                return NotFound(); // Retorna 404 si no se encuentra el detalle
            }

            // Elimina el detalle de venta
            _context.DETALLE_VENTA.Remove(detalleVenta);
            await _context.SaveChangesAsync();

            // Retorna un 204 (sin contenido) si la eliminación fue exitosa
            return NoContent();
        }
    }
}
