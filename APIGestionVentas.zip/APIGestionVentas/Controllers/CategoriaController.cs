﻿using APIGestionVentas.DBContext; // Importa el contexto de la base de datos para interactuar con las entidades
using APIGestionVentas.Models; // Importa el modelo de la entidad Categoria
using Microsoft.AspNetCore.Mvc; // Importa las herramientas necesarias para crear controladores de API
using Microsoft.EntityFrameworkCore; // Importa las extensiones para trabajar con Entity Framework Core

namespace APIGestionVentas.Controllers // Define el espacio de nombres para el controlador
{
    [Route("api/[controller]")] // Define la ruta base para las solicitudes a este controlador, reemplazando [controller] con el nombre de la clase (Categoria)
    [ApiController] // Indica que esta clase es un controlador API y aplica comportamientos específicos automáticamente
    public class CategoriaController : ControllerBase // Clase que hereda de ControllerBase, permitiendo manejar solicitudes HTTP
    {
        private readonly GestionVentasDbContext _context; // Variable privada para el contexto de la base de datos

        // Constructor que recibe el contexto de la base de datos a través de la inyección de dependencias
        public CategoriaController(GestionVentasDbContext context)
        {
            _context = context; // Inicializa el contexto
        }

        // GET: api/Categoria
        [HttpGet("Get-Categorias")] // Define un endpoint GET para obtener todas las categorías
        public async Task<ActionResult<IEnumerable<Categoria>>> GetCategorias()
        {
            // Obtiene todas las categorías de la base de datos de forma asíncrona y las devuelve como una lista
            return await _context.CATEGORIA.ToListAsync();
        }

        // GET: api/Categoria/5
        [HttpGet("Get-Categoria-Id{id}")] // Define un endpoint GET para obtener una categoría específica por ID
        public async Task<ActionResult<Categoria>> GetCategoria(int id)
        {
            // Busca la categoría en la base de datos utilizando el ID proporcionado
            var categoria = await _context.CATEGORIA.FindAsync(id);

            if (categoria == null) // Verifica si la categoría no fue encontrada
            {
                return NotFound(); // Devuelve un 404 Not Found si no existe
            }

            return categoria; // Devuelve la categoría encontrada
        }

        // POST: api/Categoria
        [HttpPost("Crear-Categoria")] // Define un endpoint POST para crear una nueva categoría
        public async Task<ActionResult<Categoria>> CrearCategoria(Categoria categoria)
        {
            // Agrega la nueva categoría al contexto
            _context.CATEGORIA.Add(categoria);
            await _context.SaveChangesAsync(); // Guarda los cambios en la base de datos

            // Devuelve un 201 Created con la ubicación de la nueva categoría creada
            return CreatedAtAction(nameof(GetCategoria), new { id = categoria.IdCategoria }, categoria);
        }

        // PUT: api/Categoria/5
        [HttpPut("Modificar-Categoria{id}")] // Define un endpoint PUT para modificar una categoría existente
        public async Task<IActionResult> ModificarCategoria(int id, Categoria categoria)
        {
            // Verifica si el ID de la categoría en la URL coincide con el ID del objeto recibido
            if (id != categoria.IdCategoria)
            {
                return BadRequest(); // Devuelve un 400 Bad Request si no coinciden
            }

            _context.Entry(categoria).State = EntityState.Modified; // Marca la categoría como modificada

            try
            {
                await _context.SaveChangesAsync(); // Guarda los cambios en la base de datos
            }
            catch (DbUpdateConcurrencyException) // Captura excepciones de concurrencia
            {
                // Verifica si la categoría sigue existiendo
                if (!CategoriaExists(id))
                {
                    return NotFound(); // Devuelve un 404 Not Found si no existe
                }
                else
                {
                    throw; // Lanza la excepción si ocurre otro tipo de error
                }
            }

            return NoContent(); // Devuelve un 204 No Content si la actualización fue exitosa
        }

        // DELETE: api/Categoria/5
        [HttpDelete("Eliminar-Categoria{id}")]
        public async Task<IActionResult> EliminarCategoria(int id)
        {
            var categoria = await _context.CATEGORIA.FindAsync(id);
            if (categoria == null)
                return NotFound("No se ha encontrado una categoría con este id");

            bool hasRelatedProductos = await _context.PRODUCTO.AnyAsync(p => p.IdCategoria == id);
            if (hasRelatedProductos)
                return BadRequest("Esta categoría tiene productos. No se puede eliminar");

            _context.CATEGORIA.Remove(categoria);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // Método privado para verificar si una categoría existe en la base de datos
        private bool CategoriaExists(int id)
        {
            // Retorna verdadero si existe una categoría con el ID proporcionado
            return _context.CATEGORIA.Any(e => e.IdCategoria == id);
        }
    }
}
