﻿// Importamos las bibliotecas necesarias para construir un controlador de API
using Microsoft.AspNetCore.Mvc; // Para manejar las solicitudes y respuestas de la API
using Microsoft.EntityFrameworkCore; // Para trabajar con Entity Framework Core

// Importamos el contexto de la base de datos y los modelos que vamos a utilizar
using APIGestionVentas.DBContext; // Importa el contexto que permite interactuar con la base de datos
using APIGestionVentas.Models; // Importa el modelo de datos que representa la entidad Cliente

namespace APIGestionVentas.Controllers // Define el espacio de nombres para el controlador
{
    // Decorador que indica que esta clase es un controlador de API
    [Route("api/[controller]")] // Define la ruta base para las solicitudes a este controlador, reemplazando [controller] con el nombre de la clase (Cliente)

    public class ClienteController : ControllerBase // Clase que hereda de ControllerBase, lo que permite gestionar solicitudes HTTP
    {
        // Creamos una variable privada para almacenar el contexto de la base de datos
        private readonly GestionVentasDbContext _context; // Variable para almacenar el contexto de la base de datos

        // Constructor del controlador que recibe el contexto de la base de datos
        public ClienteController(GestionVentasDbContext context) // Constructor que inyecta el contexto de la base de datos
        {
            _context = context; // Asignamos el contexto recibido a la variable privada
        }

        // Método para obtener todos los clientes
        [HttpGet("Get-Clientes")] // Define un endpoint GET para obtener la lista de clientes
        public async Task<IActionResult> GetClientes()
        {
            // Obtenemos la lista de clientes de la base de datos de manera asíncrona
            var clientes = await _context.CLIENTE.ToListAsync(); // Recupera todos los clientes de la tabla CLIENTE
            // Retornamos una respuesta con un mensaje y la lista de clientes
            return Ok(new { mensaje = "todo ok", response = clientes }); // Devuelve los clientes junto con un mensaje
        }

        // Método para obtener un cliente específico por su ID
        [HttpGet("Get-Clientes-Id/{id}")] // Define un endpoint GET para obtener un cliente por su ID
        public async Task<IActionResult> GetCliente(int id)
        {
            // Buscamos el cliente en la base de datos utilizando su ID
            var cliente = await _context.CLIENTE.FindAsync(id); // Busca el cliente por ID

            // Si el cliente no se encuentra, retornamos un mensaje de error
            if (cliente == null)
            {
                return NotFound(new { mensaje = "Cliente no encontrado" }); // Devuelve un mensaje de cliente no encontrado
            }

            // Si el cliente se encuentra, retornamos su información
            return Ok(new { mensaje = "todo ok", response = cliente }); // Devuelve el cliente encontrado
        }

        // Método para agregar un nuevo cliente
        [HttpPost("Crear-Cliente")] // Define un endpoint POST para crear un nuevo cliente
        public async Task<IActionResult> AgregarCliente([FromBody] Cliente cliente) // Recibe el cliente en el cuerpo de la solicitud
        {
            // Comprobamos si el cliente recibido es nulo
            if (cliente == null)
            {
                return BadRequest(new { mensaje = "Cliente no puede ser nulo." }); // Devuelve un mensaje de error si el cliente es nulo
            }

            // Aquí puedes agregar validaciones adicionales si es necesario

            // Agregamos el nuevo cliente al contexto de la base de datos
            _context.CLIENTE.Add(cliente); // Añade el cliente al contexto
            // Guardamos los cambios en la base de datos de manera asíncrona
            await _context.SaveChangesAsync(); // Guarda los cambios

            // Retornamos una respuesta indicando que el cliente fue creado, con su ID
            return CreatedAtAction(nameof(GetCliente), new { id = cliente.IdCliente }, cliente); // Devuelve 201 Created
        }

        // Método para actualizar un cliente existente
        [HttpPut("Modificar-Cliente/{id}")] // Define un endpoint PUT para actualizar un cliente existente
        public async Task<IActionResult> ActualizarCliente(int id, [FromBody] Cliente cliente) // Recibe el ID y el cliente en el cuerpo de la solicitud
        {
            // Comprobamos si el cliente recibido es nulo
            if (cliente == null)
            {
                return BadRequest(new { mensaje = "Cliente no puede ser nulo." }); // Devuelve un mensaje de error si el cliente es nulo
            }

            // Buscamos el cliente existente en la base de datos
            var clienteExistente = await _context.CLIENTE.FindAsync(id); // Busca el cliente por ID
            // Si no se encuentra, retornamos un mensaje de error
            if (clienteExistente == null)
            {
                return NotFound(new { mensaje = "Cliente no encontrado." }); // Devuelve un mensaje de cliente no encontrado
            }

            // Actualizamos las propiedades del cliente existente con los nuevos valores
            clienteExistente.Documento = cliente.Documento; // Actualiza el documento
            clienteExistente.NombreCompleto = cliente.NombreCompleto; // Actualiza el nombre completo
            clienteExistente.Correo = cliente.Correo; // Actualiza el correo
            clienteExistente.Telefono = cliente.Telefono; // Actualiza el teléfono
            clienteExistente.Estado = cliente.Estado; // Actualiza el estado
            // Puedes actualizar otras propiedades según sea necesario

            // Guardamos los cambios en la base de datos de manera asíncrona
            await _context.SaveChangesAsync(); // Guarda los cambios

            // Retornamos una respuesta indicando que el cliente fue actualizado
            return Ok(new { mensaje = "Cliente actualizado correctamente.", cliente = clienteExistente }); // Devuelve el cliente actualizado
        }

        // Método para eliminar un cliente
        [HttpDelete("Eliminar-Cliente/{id}")]
        public async Task<IActionResult> EliminarCliente(int id)
        {
            var cliente = await _context.CLIENTE.FindAsync(id);
            if (cliente == null)
                return NotFound("No se ha encontrado un cliente con este id");

            bool hasRelatedVentas = await _context.VENTA.AnyAsync(v => v.IdVenta == cliente.IdCliente);
            if (hasRelatedVentas)
                return BadRequest("Este cliente tiene ventas. No se puede eliminar");

            _context.CLIENTE.Remove(cliente);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
