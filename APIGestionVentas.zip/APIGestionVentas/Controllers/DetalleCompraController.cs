﻿using APIGestionVentas.DBContext;
using APIGestionVentas.DTOs;
using APIGestionVentas.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APIGestionVentas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DetalleCompraController : ControllerBase
    {
        private readonly GestionVentasDbContext _context;

        public DetalleCompraController(GestionVentasDbContext context)
        {
            _context = context;
        }

        // GET: api/DetalleCompra
        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetDetallesCompra()
        {
            // Obtiene todos los detalles de compra
            var detalles = await _context.DETALLE_COMPRA
                .Select(dc => new
                {
                    dc.IdDetalleCompra,
                    dc.IdCompra,
                    dc.IdProducto,
                    dc.PrecioCompra,
                    dc.PrecioVenta,
                    dc.Cantidad,
                    dc.MontoTotal,
                    dc.FechaRegistro
                })
                .ToListAsync();

            return Ok(detalles); // Retorna la lista de detalles
        }

        // GET: api/DetalleCompra/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<object>> GetDetalleCompra(int id)
        {
            // Busca el detalle de compra por ID
            var detalle = await _context.DETALLE_COMPRA
                .Where(dc => dc.IdDetalleCompra == id)
                .Select(dc => new
                {
                    dc.IdDetalleCompra,
                    dc.IdCompra,
                    dc.IdProducto,
                    dc.PrecioCompra,
                    dc.PrecioVenta,
                    dc.Cantidad,
                    dc.MontoTotal,
                    dc.FechaRegistro
                })
                .FirstOrDefaultAsync();

            // Verifica si el detalle existe
            if (detalle == null)
            {
                return NotFound(); // Retorna 404 si no se encuentra el detalle
            }

            return Ok(detalle); // Retorna el detalle de compra
        }

        // POST: api/DetalleCompra
        [HttpPost]
        public async Task<ActionResult<DetalleCompra>> PostDetalleCompra(DetalleCompra detalleCompra)
        {
            // Verifica si la entidad es válida
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Añade el nuevo detalle de compra
            _context.DETALLE_COMPRA.Add(detalleCompra);
            await _context.SaveChangesAsync();

            // Retorna un 201 (creado) con la ubicación del nuevo recurso
            return CreatedAtAction("GetDetalleCompra", new { id = detalleCompra.IdDetalleCompra }, detalleCompra);
        }

        // DELETE: api/DetalleCompra/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDetalleCompra(int id)
        {
            // Busca el detalle de compra por ID
            var detalleCompra = await _context.DETALLE_COMPRA.FindAsync(id);

            // Verifica si el detalle existe
            if (detalleCompra == null)
            {
                return NotFound(); // Retorna 404 si no se encuentra el detalle
            }

            // Elimina el detalle de compra
            _context.DETALLE_COMPRA.Remove(detalleCompra);
            await _context.SaveChangesAsync();

            // Retorna un 204 (sin contenido) si la eliminación fue exitosa
            return NoContent();
        }
    }
}
