﻿using APIGestionVentas.DBContext;
using APIGestionVentas.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APIGestionVentas.Controllers
{
    // Este controlador gestiona las operaciones CRUD para la entidad "Rol".
    [Route("api/[controller]")]
    [ApiController]
    public class RolController : ControllerBase
    {
        private readonly GestionVentasDbContext _context;

        // Constructor que inyecta el contexto de la base de datos.
        public RolController(GestionVentasDbContext context)
        {
            _context = context;
        }

        // GET: api/Rol
        // Método que obtiene todos los roles almacenados en la base de datos.
        [HttpGet("Get-Roles")]
        public async Task<ActionResult<IEnumerable<Rol>>> GetRoles()
        {
            // Retorna la lista de roles como un IEnumerable, útil para consultas simples.
            return await _context.ROL.ToListAsync();
        }

        // GET: api/Rol/5
        // Método para obtener un rol específico por su Id.
        [HttpGet("Get-Rol-Id{id}")]
        public async Task<ActionResult<Rol>> GetRol(int id)
        {
            // Busca el rol en la base de datos utilizando el método FindAsync.
            var rol = await _context.ROL.FindAsync(id);

            // Si no se encuentra el rol, devuelve un código 404.
            if (rol == null)
            {
                return NotFound();
            }

            // Devuelve el rol encontrado.
            return rol;
        }

        // POST: api/Rol
        // Método para crear un nuevo rol.
        [HttpPost("Crear-Rol")]
        public async Task<ActionResult<Rol>> CrearRol(Rol rol)
        {
            // Añade el nuevo rol al contexto.
            _context.ROL.Add(rol);
            // Guarda los cambios de forma asincrónica en la base de datos.
            await _context.SaveChangesAsync();

            // Retorna el rol creado y el código de respuesta 201.
            return CreatedAtAction(nameof(GetRol), new { id = rol.IdRol }, rol);
        }

        // PUT: api/Rol/5
        // Método para modificar un rol existente.
        [HttpPut("Modificar-Rol{id}")]
        public async Task<IActionResult> ModificarRol(int id, Rol rol)
        {
            // Verifica que el Id proporcionado en la ruta y el Id en el cuerpo coincidan.
            if (id != rol.IdRol)
            {
                return BadRequest();
            }

            // Marca el estado de la entidad como "modificado".
            _context.Entry(rol).State = EntityState.Modified;

            try
            {
                // Intenta guardar los cambios en la base de datos.
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                // Si el rol no existe, retorna un código 404.
                if (!RolExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            // Retorna un código 204 indicando que la operación fue exitosa.
            return NoContent();
        }

        // DELETE: api/Rol/5
        // Método para eliminar un rol existente.
        [HttpDelete("Eliminar-Rol{id}")]
        public async Task<IActionResult> EliminarRol(int id)
        {
            var rol = await _context.ROL.FindAsync(id);
            if (rol == null)
                return NotFound("No se ha encontrado un rol con este id");

            // Check if there are any related Usuario records
            bool hasRelatedUsuarios = await _context.USUARIO.AnyAsync(u => u.IdRol == id);
            if (hasRelatedUsuarios)
                return BadRequest("Este rol tiene usuarios asignados. No se puede eliminar");

            _context.ROL.Remove(rol);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // Método privado para verificar si un rol existe.
        private bool RolExists(int id)
        {
            // Comprueba si existe algún rol con el Id proporcionado.
            return _context.ROL.Any(e => e.IdRol == id);
        }
    }
}
