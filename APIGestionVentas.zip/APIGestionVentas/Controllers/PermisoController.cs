﻿// Importamos las bibliotecas necesarias para trabajar con el contexto de la base de datos, modelos y controladores de API
using APIGestionVentas.DBContext;
using APIGestionVentas.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace APIGestionVentas.Controllers
{
    // Define la ruta base para las solicitudes a este controlador
    [Route("api/[controller]")]
    // Indica que esta clase es un controlador de API
    [ApiController]
    public class PermisosController : ControllerBase
    {
        // Creamos una variable privada para almacenar el contexto de la base de datos
        private readonly GestionVentasDbContext _context;

        // Constructor del controlador que recibe el contexto de la base de datos
        public PermisosController(GestionVentasDbContext context)
        {
            _context = context; // Asignamos el contexto recibido a la variable privada
        }

        // Método para obtener todos los permisos
        // Ruta: GET api/permisos
        [HttpGet("Get-Permisos")]
        public async Task<ActionResult<IEnumerable<Permiso>>> GetPermisos()
        {
            // Obtenemos la lista de permisos de la base de datos de manera asíncrona
            var permisos = await _context.PERMISO.ToListAsync();
            // Retornamos una respuesta exitosa con la lista de permisos
            return Ok(permisos);
        }

        // Método para obtener un permiso específico por su ID
        // Ruta: GET api/permisos/{id}
        [HttpGet("Get-Permisos-Id/{id}")]
        public async Task<ActionResult<Permiso>> GetPermisoPorId(int id)
        {
            // Buscamos el permiso en la base de datos utilizando su ID
            var permiso = await _context.PERMISO.FindAsync(id);
            // Si el permiso no se encuentra, retornamos un 404 Not Found
            if (permiso == null)
            {
                return NotFound();
            }
            // Si el permiso se encuentra, retornamos su información
            return Ok(permiso);
        }

        // Método para agregar un nuevo permiso
        // Ruta: POST api/permisos
        [HttpPost("Crear-Permiso")]
        public async Task<ActionResult<Permiso>> CrearPermiso(Permiso nuevoPermiso)
        {
            // Validamos que el nombre del menú y el ID del rol sean válidos
            if (string.IsNullOrWhiteSpace(nuevoPermiso.NombreMenu) || nuevoPermiso.IdRol <= 0)
            {
                return BadRequest("El NombreMenu y el IdRol son obligatorios.");
            }

            // Agregamos el nuevo permiso al contexto de la base de datos
            _context.PERMISO.Add(nuevoPermiso);
            // Guardamos los cambios en la base de datos de manera asíncrona
            await _context.SaveChangesAsync();
            // Retornamos una respuesta indicando que el permiso fue creado, junto con su ID
            return CreatedAtAction(nameof(GetPermisoPorId), new { id = nuevoPermiso.IdPermiso }, nuevoPermiso);
        }

        // Método para actualizar un permiso existente
        // Ruta: PUT api/permisos/{id}
        [HttpPut("Modificar-Permiso/{id}")]
        public async Task<IActionResult> ModificarPermiso(int id, Permiso permisoActualizado)
        {
            // Comprobamos que el ID del permiso actualizado coincida con el ID de la ruta
            if (id != permisoActualizado.IdPermiso)
            {
                return BadRequest("El ID del permiso no coincide.");
            }

            // Buscamos el permiso existente en la base de datos
            var permisoExistente = await _context.PERMISO.FindAsync(id);
            // Si no se encuentra, retornamos un 404 Not Found
            if (permisoExistente == null)
            {
                return NotFound();
            }

            // Actualizamos las propiedades del permiso existente
            permisoExistente.IdRol = permisoActualizado.IdRol;
            permisoExistente.NombreMenu = permisoActualizado.NombreMenu;
            permisoExistente.FechaRegistro = DateTime.Now; // Actualizamos la fecha de registro a la fecha actual

            // Guardamos los cambios en la base de datos de manera asíncrona
            await _context.SaveChangesAsync();
            // Retornamos un 204 No Content, indicando que la actualización fue exitosa
            return NoContent();
        }

        // Método para eliminar un permiso
        // Ruta: DELETE api/permisos/{id}
        [HttpDelete("Eliminar-Permiso/{id}")]
        public async Task<IActionResult> EliminarPermiso(int id)
        {
            // Buscamos el permiso existente en la base de datos
            var permiso = await _context.PERMISO.FindAsync(id);
            // Si no se encuentra, retornamos un 404 Not Found
            if (permiso == null)
            {
                return NotFound();
            }

            // Eliminamos el permiso del contexto de la base de datos
            _context.PERMISO.Remove(permiso);
            // Guardamos los cambios en la base de datos de manera asíncrona
            await _context.SaveChangesAsync();

            // Retornamos un 204 No Content, indicando que la eliminación fue exitosa
            return NoContent();
        }
    }
}
