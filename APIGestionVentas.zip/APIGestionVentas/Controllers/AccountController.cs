using APIGestionVentas.DBContext;
using APIGestionVentas.Models.Api;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using APIGestionVentas.Services;

public class AccountController : ControllerBase
{
    private readonly JwtService _jwtService;
    private readonly GestionVentasDbContext _dbContext;

    public AccountController(JwtService jwtService, GestionVentasDbContext dbContext)
    {
        _jwtService = jwtService;
        _dbContext = dbContext;
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequestModel request)
{
    // Validar credenciales
    var user = await _dbContext.USUARIO
        .Include(u => u.Rol) // Incluye rol
        .FirstOrDefaultAsync(u => u.NombreCompleto == request.UserName && u.Clave == request.Password);

    if (user == null)
    {
        return Unauthorized("Invalid credentials");
    }


    var roleId = user.Rol?.IdRol;

    if (roleId == null)
    {
        return Unauthorized("User does not have an assigned role");
    }

    // genera token
    var token = _jwtService.GenerateJwtToken(user.NombreCompleto, roleId.ToString());

    return Ok(new { Token = token });
}}