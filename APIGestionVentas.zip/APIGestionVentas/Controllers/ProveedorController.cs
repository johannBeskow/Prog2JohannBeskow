﻿using APIGestionVentas.DBContext;
using APIGestionVentas.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APIGestionVentas.Controllers
{
    // Define la ruta base para las solicitudes a este controlador
    [Route("api/[controller]")]
    // Indica que esta clase es un controlador de API
    [ApiController]
    public class ProveedorController:ControllerBase
    {

        private readonly GestionVentasDbContext _context;
        public ProveedorController(GestionVentasDbContext context) 
        {
            _context = context;
        }

        // GET: api/proveedor
        [HttpGet("Get-Proveedores")]
        public async Task<ActionResult<IEnumerable<Proveedor>>> GetProveedores()
        {
            // Obtenemos la lista de proveedores de la base de datos
            var proveedores = await _context.PROVEEDOR.ToListAsync();

            // Retornamos la lista de proveedores
            return Ok(new { mensaje = "todo ok", response = proveedores });
        }

        // GET: api/proveedor/{id}
        [HttpGet("Get-Proveedores-Id/{id}")]
        public async Task<ActionResult<Proveedor>> GetProveedor(int id)
        {
            // Busca el proveedor por ID en la base de datos
            var proveedor = await _context.PROVEEDOR.FindAsync(id);

            // Verifica si el proveedor existe
            if (proveedor == null)
            {
                return NotFound(); // Devuelve un 404 si no se encuentra
            }

            return Ok(proveedor); // Devuelve el proveedor encontrado
        }

        // POST: api/Proveedor
        [HttpPost("Crear-Proveedor")]
        public async Task<ActionResult<Proveedor>> CrearProveedor(Proveedor proveedor)
        {
            // Validar si el objeto 'proveedor' no es nulo
            if (proveedor == null)
            {
                return BadRequest("El proveedor no puede ser nulo.");
            }

            // Agregar el proveedor al contexto
            _context.PROVEEDOR.Add(proveedor);

            // Guardar los cambios de forma asíncrona
            await _context.SaveChangesAsync();

            // Retornar el proveedor creado, junto con el estado 201 Created
            return CreatedAtAction(nameof(GetProveedor), new { id = proveedor.IdProveedor }, proveedor);
        }


        // PUT: api/Proveedor/5
        [HttpPut("Modificar-Proveedor{id}")]
        public async Task<IActionResult> ModificarProveedor(int id, Proveedor proveedor)
        {
            // Validar si el ID del proveedor coincide con el ID del objeto que se envía
            if (id != proveedor.IdProveedor)
            {
                return BadRequest("El ID del proveedor en la URL no coincide con el ID en el cuerpo.");
            }

            // Marcar el objeto como modificado
            _context.Entry(proveedor).State = EntityState.Modified;

            try
            {
                // Guardar los cambios de forma asíncrona
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                // Verificar si el proveedor existe antes de intentar actualizar
                if (!ProveedorExists(id))
                {
                    return NotFound("El proveedor con el ID especificado no fue encontrado.");
                }
                else
                {
                    throw;
                }
            }

            // Retornar código 204 NoContent indicando que la actualización fue exitosa
            return NoContent();
        }

        // Método auxiliar para verificar si el proveedor existe
        private bool ProveedorExists(int id)
        {
            return _context.PROVEEDOR.Any(e => e.IdProveedor == id);
        }

        // DELETE: api/Proveedor/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarProveedor(int id)
        {
            var proveedor = await _context.PROVEEDOR.FindAsync(id);
            if (proveedor == null)
                return NotFound("no se ha encontrado un proveedor con este id");

            bool hasRelatedCompras = await _context.COMPRA.AnyAsync(c => c.IdProveedor == id);
            if (hasRelatedCompras)
                return BadRequest("este proveedor tiene compras. No se puede eliminar");

            _context.PROVEEDOR.Remove(proveedor);
            await _context.SaveChangesAsync();
            return NoContent();
        }


    }
}
